#include <stdio.h>

int main()
{
	printf("Hello Daemon\n");
	while(1);
	return 0;
}
